
document.getElementById('user').innerHTML = sessionStorage.getItem('user');