
const url = 'http://localhost:4000';
const url2 = 'http://localhost/ProyectoOREVE/serverSF/public/index.php'; //DIEGO

//const url2 = 'http://localhost:8080/OREVE/serverSF/public/index.php'; //COKER